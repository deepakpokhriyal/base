<html>
	<body>
		<applet CODEBASE="."
			ARCHIVE="jta.jar"
			CODE="de.mud.jta.Applet" 
			WIDTH="100%" HEIGHT="100%">
		<param name="config" value="config.php">
		</applet>
	</body>
</html>
