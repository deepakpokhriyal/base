<?php

$locales['pl_PL'] = array(
			  // name is what appears on the login page language selection
			   'name' => 'Polish',
			   // charset shows up in the HTML head section
			   'charset' => 'iso-8859-2',
			   'date_format' => '',
			   // the below are so we know how to pass this language to our 3rd party programs
			   'filemanager' => 'polish',
			   'phpmyadmin' => 'pl-utf-8',
			   'sysinfo' => 'pl',
			   'awstats' => 'pl'
			   );

?>