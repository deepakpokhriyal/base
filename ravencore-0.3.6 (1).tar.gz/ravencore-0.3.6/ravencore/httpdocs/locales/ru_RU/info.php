<?php

$locales['ru_RU'] = array(
			  'name' => 'Russian',
			  'charset' => 'windows-1251',
			  'date_format' => '',
			  'filemanager' => 'russian',
			  'phpmyadmin' => 'ru-utf-8',
			  'sysinfo' => 'ru',
			  'awstats' => 'ru'
			  );

?>