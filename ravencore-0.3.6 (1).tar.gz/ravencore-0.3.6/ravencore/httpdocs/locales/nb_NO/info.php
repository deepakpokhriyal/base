<?php

$locales['nb_NO'] = array(
			  'name' => 'Norwegian',
			  'charset' => 'iso-8859-15',
			  'date_format' => '',
			  'filemanager' => 'norwegian',
			  'phpmyadmin' => 'no-utf-8',
			  'sysinfo' => 'no',
			  'awstats' => 'nb'
			  );

?>